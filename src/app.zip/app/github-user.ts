export class GithubUser {
    followers: number;
    public_repos: number;
}
